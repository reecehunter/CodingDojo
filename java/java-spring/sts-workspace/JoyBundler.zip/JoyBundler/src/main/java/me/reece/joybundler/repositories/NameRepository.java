package me.reece.joybundler.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import me.reece.joybundler.models.Name;

@Repository
public interface NameRepository extends CrudRepository<Name, Long> {
	// get one
	Optional<Name> findById(Long id);
	// get all
	List<Name> findAll();

}