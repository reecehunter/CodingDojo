package me.reece.joybundler.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import me.reece.joybundler.models.Name;
import me.reece.joybundler.repositories.NameRepository;

@Service
public class NameService {
	private final NameRepository repo;
	
	public NameService(NameRepository repo) {
		this.repo = repo;
	}
	
	public Name createOne(Name name) {
		return repo.save(name);
	}
	
	public Name getOne(Long id) {
		Optional<Name> potential = repo.findById(id);
		return potential.isPresent() ? potential.get(): null;
	}
	
	public List<Name> getAll() {
		return repo.findAll();
	}
    
    public Name update(Name name) {
    	System.out.println("id: " + name.getId());
		Optional<Name> optional = repo.findById(name.getId());
		if(optional.isPresent()) {
			return repo.save(name);
		} else {
	    	return null;
		}
    }
    
    public void delete(Long id) {
		Optional<Name> optional = repo.findById(id);
		if(optional.isPresent()) {
			Name name = optional.get();
			repo.delete(name);
		}
    }

}