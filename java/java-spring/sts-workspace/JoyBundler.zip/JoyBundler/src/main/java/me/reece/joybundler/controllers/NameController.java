package me.reece.joybundler.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import me.reece.joybundler.models.Name;
import me.reece.joybundler.models.LoginUser;
import me.reece.joybundler.models.User;
import me.reece.joybundler.models.ValidateName;
import me.reece.joybundler.services.NameService;
import me.reece.joybundler.services.UserService;

@Controller
@RequestMapping("/names")
public class NameController {
	private final NameService nameService;
	private final UserService userService;
	
	public NameController(NameService nameService, UserService userService) {
		this.nameService = nameService;
		this.userService = userService;
	}
	
	@GetMapping("")
	public String showAll(Model model, HttpSession session) {
		if(session.getAttribute("user_id") == null) {
			return "redirect:/users";
		}
		final long id = (long) session.getAttribute("user_id");
		User user = userService.getUser(id);
		model.addAttribute("user", user);
		
		List<Name> names = nameService.getAll();
		model.addAttribute("names", names);
		return "/name/showAll.jsp";
	}
	
	@GetMapping("/{id}")
	public String showOne(
			@PathVariable("id") long id,
			Model model,
			HttpSession session) {
		if(session.getAttribute("user_id") == null) {
			return "redirect:/users";
		}
		Name name = nameService.getOne(id);
		model.addAttribute("name", name);
		return "/name/showOne.jsp";
	}
	
	@GetMapping("/new")
	public String newName(
			@ModelAttribute("newName") Name name,
			@ModelAttribute("validateName") LoginUser loginUser,
			Model model,
			HttpSession session) {
		if(session.getAttribute("user_id") == null) {
			return "redirect:/users";
		}
		final long id = (long) session.getAttribute("user_id");
		User user = userService.getUser(id);
		model.addAttribute("user", user);
		return "/name/new.jsp";
	}
	
	@PostMapping("/process/new")
	public String processNewName(
			@Valid @ModelAttribute("newName") Name name,
			BindingResult result,
			Model model,
			HttpSession session) {
		// re-render if errors
		if(result.hasErrors()) {
			model.addAttribute("validateName", new ValidateName());
			return "/name/new.jsp";
		}
		
		Name newName = nameService.createOne(name);
		return "redirect:/names/"+newName.getId();
	}
	
	@GetMapping("/edit/{id}")
	public String editOne(
			@ModelAttribute("newName") Name newName,
			@ModelAttribute("validateName") ValidateName validateName,
			@PathVariable("id") long id,
			Model model,
			HttpSession session) {
		if(session.getAttribute("user_id") == null) {
			return "redirect:/users";
		}
		Name name = nameService.getOne(id);
		model.addAttribute("name", name);
		return "/name/edit.jsp";
	}
	
	@PostMapping("/process/edit/{id}")
	public String processEditOne(
			@PathVariable("id") long id,
			@Valid @ModelAttribute("newName") Name name,
			BindingResult result,
			Model model,
			HttpSession session) {
		if(result.hasErrors()) {
			model.addAttribute("name", name);
			return "/name/edit.jsp";
		}
		nameService.update(name);
		return "redirect:/names/" + id;
	}
	
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable("id") Long id) {
		nameService.delete(id);
		return "redirect:/names";
	}

}
