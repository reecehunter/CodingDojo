package me.reece.joybundler.models;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ValidateName {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message="Name is required!")
    @Size(min=2, max=255, message="Username must be at least 2 characters")
    private String name;
    
    @NotBlank(message="Gender is required!")
    @Size(max=255)
    private String gender;
    
    @NotBlank(message="Origin is required!")
    @Size(min=2, max=255, message="Origin must be at least 2 characters!")
    private String origin;
    
    @NotBlank(message="Meaning is required!")
    @Size(min=3, max=255, message="Meaning must be at least 3 characters!")
    private String meaning;
    
    
	public ValidateName() {
		// TODO Auto-generated constructor stub
	}

	// Getters and setters
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getOrigin() {
		return origin;
	}


	public void setOrigin(String origin) {
		this.origin = origin;
	}


	public String getMeaning() {
		return meaning;
	}


	public void setMeaning(String meaning) {
		this.meaning = meaning;
	}


	public Long getId() {
		return id;
	}
}