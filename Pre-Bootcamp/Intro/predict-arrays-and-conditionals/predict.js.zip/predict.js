// Snippet #1
//    auntContactInfo = ["Paula", "Smith", "1234 Main Street", "St. Louis", "MO", 12345]

// Snippet #2
//    produce = ["apples", "oranges"] =
//    frozen = ["broccoli", "ice cream"] = ["broccoli", "ice cream", "hashbrowns"]

// Snippet #3
//    movieLibrary = ["Bambi", "E.T.", "Toy Story"] = ["Bambi", "E.T.", "Toy Story", "Zoro"] = ["Bambi", "Beetlejuice", "Toy Story", "Zoro"]
//
