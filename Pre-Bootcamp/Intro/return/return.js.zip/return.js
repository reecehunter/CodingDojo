// Snippet #1
//     No vars

// Snippet #2
//     result = 15

// Snippet #3
//     result = 18

// Snippet #4
//     num = 15
//     result = 10

// Snippet #5
//     num = 15
//     result = 20

// Snippet #6
//     result = 16

// Snippet #7
//     No vars

// Snippet #8
//     No vars

// Snippet #9
//     result = 13

// Snippet #10
//     sum = 5 = 3 = 6 = 3 = 5 = 8
//     result = 11
