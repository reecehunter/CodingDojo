from flask_app import app
from flask import redirect, request, session, render_template
from flask_app.models.model_user import User
from flask_app.models.model_sighting import Sighting

@app.route("/new/sighting")
def sighting_create():
    if "user" not in session:
        return redirect("/")
    user = session["user"]
    return render_template("create_sighting.html", user=user)

@app.route("/new/sighting/submit", methods=["POST"])
def sighting_create_submit():
    if not Sighting.validate(request.form):
        return redirect("/new/sighting")
    new_sighting = Sighting.create(request.form)
    return redirect(f"/view/{new_sighting}")

@app.route("/view/<int:id>")
def sighting_view_one(id):
    if "user" not in session:
        return redirect("/")
    sighting = Sighting.read_one_with_user({"id": id})
    if not sighting:
        return redirect("/sightings")
    return render_template("sighting.html", user=session["user"], sighting=sighting["sighting"], sighting_user=sighting["user"])

@app.route("/edit/<int:id>")
def sighting_edit(id):
    if "user" not in session:
        return redirect("/")
    sighting = Sighting.read_one_with_user({"id": id})
    return render_template("edit_sighting.html", user=session["user"], sighting=sighting["sighting"])

@app.route("/edit/<int:id>/submit", methods=["POST"])
def sighting_edit_submit(id):
    if "user" not in session:
        return redirect("/")
    if not Sighting.validate(request.form):
        return redirect(f"/sighting/edit/{id}")
    Sighting.update(request.form)
    return redirect(f"/view/{id}")

@app.route("/sightings")
def sighting_view_all():
    if "user" not in session:
        return redirect("/")
    sightings = Sighting.read_all_with_users()
    print(sightings)
    return render_template("sightings.html", user=session["user"], sightings=sightings)

@app.route("/delete/<int:id>")
def delete_one(id):
    if "user" not in session:
        return redirect("/")
    Sighting.delete_one({"sighting_id": id})
    return redirect("/sightings")