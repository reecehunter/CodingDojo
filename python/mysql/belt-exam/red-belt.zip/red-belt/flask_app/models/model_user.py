from flask import flash
from flask_app.config.mysqlconnection import connectToMySQL
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class User:
    DB = "sasquatch_sightings_schema"

    def __init__(self, data):
        self.id = data["id"]
        self.first_name = data["first_name"]
        self.last_name = data["last_name"]
        self.email = data["email"]
        self.password = data["password"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]

    @classmethod
    def create(cls, data):
        query = "INSERT INTO users (first_name, last_name, email, password) VALUES (%(fname)s, %(lname)s, %(email)s, %(password)s);"
        return connectToMySQL(cls.DB).query_db(query, data)

    @classmethod
    def read_sightings(cls, data):
        query = "SELECT sightings.id,sightings.user_id FROM sightings LEFT JOIN users ON sightings.user_id = users.id WHERE sightings.user_id = %(user_id)s;"
        results = connectToMySQL(cls.DB).query_db(query, data)
        if not results:
            return False
        sightings = []
        for result in results:
            sightings.append(cls(result))
        return sightings


    @classmethod
    def read_one_by_email(cls, data):
        query = "SELECT * FROM users WHERE email = %(email)s;"
        results = connectToMySQL(cls.DB).query_db(query, data)
        if not results:
            return False
        return cls(results[0])

    @classmethod
    def read_one_by_id(cls, data):
        query = "SELECT * FROM users WHERE id = %(id)s;"
        results = connectToMySQL(cls.DB).query_db(query, data)
        if not results:
            return False
        return cls(results[0])

    @staticmethod
    def validate_login(data):
        isValid = True
        if not User.read_one_by_email(data):
            flash("User not found with those credentials.")
            isValid = False
        if not EMAIL_REGEX.match(data["email"]):
            flash("Invalid email address format!")
            isValid = False
        if len(data["email"]) < 1:
            flash("Enter an email.")
            isValid = False
        if len(data["password"]) < 1:
            flash("Enter a password.")
            isValid = False
        return isValid

    @staticmethod
    def validate_create(data):
        isValid = True
        if User.read_one_by_email(data):
            flash("Email already exists!")
            isValid = False
        if len(data["fname"]) < 1:
            flash("Your first name must be greater than 1 characters.")
            isValid = False
        if len(data["lname"]) < 1:
            flash("Your last name must be greater than 1 characters.")
            isValid = False
        if not EMAIL_REGEX.match(data["email"]):
            flash("Invalid email address!")
            isValid = False
        if len(data["password"]) < 8:
            flash("Your password must be at least 8 characters.")
            isValid = False
        if data["password"] != data["confirm-password"]:
            flash("Passwords must match.")
            isValid = False
        return isValid