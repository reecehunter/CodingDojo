from flask import flash
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.controllers.controller_user import User
import re

class Sighting:
    DB = "sasquatch_sightings_schema"

    def __init__(self, data):
        self.id = data["id"]
        self.user_id = data["user_id"]
        self.location = data["location"]
        self.description = data["description"]
        self.date = data["date"]
        self.amount = data["amount"]
        self.created_at = data["created_at"]
        self.updated_at = data["updated_at"]

    @classmethod
    def create(cls, data):
        query = "INSERT INTO sightings (user_id, location, description, date, amount) VALUES (%(user_id)s, %(location)s, %(description)s, %(date)s, %(amount)s);"
        results = connectToMySQL(cls.DB).query_db(query, data)
        if not results:
            return False
        return results

    @classmethod
    def update(cls, data):
        query = "UPDATE sightings SET location=%(location)s, description=%(description)s, date=%(date)s, amount=%(amount)s WHERE id = %(sighting_id)s;"
        return connectToMySQL(cls.DB).query_db(query, data)

    @classmethod
    def read_one(cls, data):
        query = "SELECT * FROM sightings WHERE id = %(id)s;"
        results = connectToMySQL(cls.DB).query_db(query, data)
        if not results:
            return False
        return cls(results[0])

    @classmethod
    def read_all(cls):
        query = "SELECT * FROM sightings;"
        results = connectToMySQL(cls.DB).query_db(query)
        if not results:
            return False
        sightings = []
        for result in results:
            sightings.append(cls(result))
        return sightings


    @classmethod
    def read_all_with_users(cls):
        query =  """SELECT sightings.*,
            users.id AS "user_user_id",
            users.first_name, users.last_name, users.email, users.password,
            users.created_at AS "user_created_at",
            users.updated_at AS "user_updated_at"
            FROM sightings
            JOIN users ON sightings.user_id = users.id;"""
        results = connectToMySQL(cls.DB).query_db(query)
        if not results:
            return []
        sightings_with_users = []
        for result in results:
            sighting_data = {
                "id": result["id"],
                "user_id": result["user_id"],
                "location": result["location"],
                "description": result["description"],
                "date": result["date"],
                "amount": result["amount"],
                "created_at": result["created_at"],
                "updated_at": result["updated_at"],
            }
            user_data = {
                "id": result["user_user_id"],
                "first_name": result["first_name"],
                "last_name": result["last_name"],
                "email": result["email"],
                "password": result["password"],
                "created_at": result["user_created_at"],
                "updated_at": result["user_updated_at"],
            }
            all_data = {"sighting":cls(sighting_data), "user": User(user_data)}
            sightings_with_users.append(all_data)

        return sightings_with_users

    @classmethod
    def read_one_with_user(cls, data):
        query = """SELECT sightings.*,
            users.id AS "user_user_id",
            users.first_name, users.last_name, users.email, users.password,
            users.created_at AS "user_created_at",
            users.updated_at AS "user_updated_at"
            FROM sightings JOIN users ON sightings.user_id = users.id WHERE sightings.id = %(id)s;"""
        results = connectToMySQL(cls.DB).query_db(query, data)
        if not results:
            return []
        sighting_data = {
            "id": results[0]["id"],
            "user_id": results[0]["user_id"],
            "location": results[0]["location"],
            "description": results[0]["description"],
            "date": results[0]["date"],
            "amount": results[0]["amount"],
            "created_at": results[0]["created_at"],
            "updated_at": results[0]["updated_at"],
        }
        user_data = {
            "id": results[0]["user_user_id"],
            "first_name": results[0]["first_name"],
            "last_name": results[0]["last_name"],
            "email": results[0]["email"],
            "password": results[0]["password"],
            "created_at": results[0]["user_created_at"],
            "updated_at": results[0]["user_updated_at"],
        }
        all_data = {"sighting":cls(sighting_data), "user": User(user_data)}
        return all_data

    @classmethod
    def delete_one(cls, data):
        query = "DELETE FROM sightings WHERE id = %(sighting_id)s;"
        return connectToMySQL(cls.DB).query_db(query, data)

    @staticmethod
    def validate(data):
        isValid = True
        if len(data["location"]) < 1:
            flash("Location must be more than 1 character.")
            isValid = False
        if len(data["description"]) < 3:
            flash("Description must be more than 3 characters.")
            isValid = False
        if data["date"] == "":
            flash("You must select a date.")
            isValid = False
        if int(data["amount"]) < 1:
            flash("Amount must be at least 1.")
            isValid = False
        return isValid