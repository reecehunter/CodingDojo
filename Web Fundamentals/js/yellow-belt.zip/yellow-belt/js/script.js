function removeElement(e) {
    e.remove();
}

function likePost(e) {
    const LikeCountElement = e.nextSibling.nextSibling;
    LikeCountElement.textContent = Number(LikeCountElement.textContent) + 1;
}

function handleSearch(e) {
    e.preventDefault();
    const value = document.querySelector("#search-input").value;
    alert('You are searching for "' + value + '"');
}